# AYARSHI - Real-time Chat Implementation Guide

## Table of Contents
1. [Setup & Installation](#setup--installation)
2. [Backend Implementation](#backend-implementation)
3. [Frontend Implementation](#frontend-implementation)
4. [Socket Events](#socket-events)
5. [Message Persistence](#message-persistence)
6. [Scalability](#scalability)
7. [Security](#security)

---

## SETUP & INSTALLATION

### Install Dependencies
```bash
# Backend
npm install socket.io express cors dotenv redis socket.io-redis

# Frontend
npm install socket.io-client
```

---

## BACKEND IMPLEMENTATION

### 1. Socket.io Server Setup

**File: src/socket/socketHandler.js**

```javascript
const socketIO = require('socket.io');
const redis = require('redis');
const { createAdapter } = require('@socket.io/redis-adapter');
const { Message, Booking, User } = require('../models');
const jwt = require('jsonwebtoken');

class SocketHandler {
  constructor(server) {
    this.io = socketIO(server, {
      cors: {
        origin: process.env.FRONTEND_URL,
        methods: ['GET', 'POST'],
        credentials: true,
      },
      transports: ['websocket', 'polling'],
    });

    // Redis adapter for scalability
    this.pubClient = redis.createClient({
      host: process.env.REDIS_HOST,
      port: process.env.REDIS_PORT,
    });

    this.subClient = this.pubClient.duplicate();

    this.setupMiddleware();
    this.setupConnections();
    this.setupRedisAdapter();
  }

  /**
   * Middleware - Authenticate socket connections
   */
  setupMiddleware() {
    this.io.use((socket, next) => {
      const token = socket.handshake.auth.token;

      if (!token) {
        return next(new Error('Authentication error'));
      }

      try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        socket.userId = decoded.id;
        socket.userType = decoded.user_type;
        next();
      } catch (error) {
        next(new Error('Invalid token'));
      }
    });
  }

  /**
   * Setup Redis adapter for horizontal scaling
   */
  setupRedisAdapter() {
    Promise.all([this.pubClient.connect(), this.subClient.connect()]).then(() => {
      this.io.adapter(createAdapter(this.pubClient, this.subClient));
      console.log('Redis adapter connected for Socket.io');
    });
  }

  /**
   * Main connection handler
   */
  setupConnections() {
    this.io.on('connection', (socket) => {
      console.log(`User ${socket.userId} connected: ${socket.id}`);

      // User connected event
      socket.emit('connection_established', {
        message: 'Connected to chat server',
        socketId: socket.id,
      });

      // Join booking room
      socket.on('join_chat', this.handleJoinChat.bind(this, socket));

      // Send message
      socket.on('send_message', this.handleSendMessage.bind(this, socket));

      // Read message
      socket.on('read_message', this.handleReadMessage.bind(this, socket));

      // Typing indicator
      socket.on('typing', this.handleTyping.bind(this, socket));
      socket.on('stop_typing', this.handleStopTyping.bind(this, socket));

      // Disconnect
      socket.on('disconnect', this.handleDisconnect.bind(this, socket));
    });
  }

  /**
   * JOIN CHAT ROOM
   * User joins a booking's chat room
   */
  async handleJoinChat(socket, { bookingId }) {
    try {
      // Verify user has access to this booking
      const booking = await Booking.findById(bookingId);

      if (!booking) {
        socket.emit('error', { message: 'Booking not found' });
        return;
      }

      // Check authorization
      if (
        booking.customer_id.toString() !== socket.userId &&
        booking.provider_id.toString() !== socket.userId
      ) {
        socket.emit('error', { message: 'Unauthorized access' });
        return;
      }

      // Join room
      socket.join(`booking_${bookingId}`);
      socket.bookingId = bookingId;

      // Get chat history (last 50 messages)
      const chatHistory = await Message.find({ booking_id: bookingId })
        .sort({ created_at: -1 })
        .limit(50)
        .populate('sender_id', 'name profile_photo_url');

      // Send chat history to user
      socket.emit('chat_history', {
        messages: chatHistory.reverse(),
      });

      // Notify others in room
      socket.to(`booking_${bookingId}`).emit('user_joined', {
        userId: socket.userId,
        message: 'User joined chat',
      });
    } catch (error) {
      console.error('Join chat error:', error);
      socket.emit('error', { message: 'Failed to join chat' });
    }
  }

  /**
   * SEND MESSAGE
   * Handle incoming messages
   */
  async handleSendMessage(socket, messageData) {
    try {
      const { bookingId, messageText } = messageData;

      // Validate message
      if (!messageText || messageText.trim().length === 0) {
        socket.emit('error', { message: 'Message cannot be empty' });
        return;
      }

      if (messageText.length > 1000) {
        socket.emit('error', { message: 'Message too long (max 1000 chars)' });
        return;
      }

      // Verify booking access
      const booking = await Booking.findById(bookingId);
      if (!booking) {
        socket.emit('error', { message: 'Booking not found' });
        return;
      }

      // Save message to database
      const message = await Message.create({
        booking_id: bookingId,
        sender_id: socket.userId,
        receiver_id:
          booking.customer_id.toString() === socket.userId
            ? booking.provider_id
            : booking.customer_id,
        message_text: messageText,
        is_read: false,
        created_at: new Date(),
      });

      // Populate sender info
      await message.populate('sender_id', 'name profile_photo_url');

      // Emit to all users in room
      this.io.to(`booking_${bookingId}`).emit('new_message', {
        id: message._id,
        sender_id: message.sender_id,
        message_text: message.message_text,
        created_at: message.created_at,
        is_read: message.is_read,
      });

      // Emit confirmation to sender
      socket.emit('message_sent', {
        id: message._id,
        status: 'sent',
      });

      // Send notification to receiver if offline
      await this.sendOfflineNotification(bookingId, socket.userId);
    } catch (error) {
      console.error('Send message error:', error);
      socket.emit('error', { message: 'Failed to send message' });
    }
  }

  /**
   * READ MESSAGE
   * Mark message as read
   */
  async handleReadMessage(socket, { messageId, bookingId }) {
    try {
      // Update message in database
      const message = await Message.findByIdAndUpdate(
        messageId,
        { is_read: true },
        { new: true }
      );

      // Notify sender that message was read
      this.io.to(`booking_${bookingId}`).emit('message_read', {
        messageId: messageId,
        timestamp: new Date(),
      });
    } catch (error) {
      console.error('Read message error:', error);
    }
  }

  /**
   * TYPING INDICATOR
   * Show user is typing
   */
  async handleTyping(socket, { bookingId }) {
    try {
      socket.to(`booking_${bookingId}`).emit('user_typing', {
        userId: socket.userId,
      });
    } catch (error) {
      console.error('Typing error:', error);
    }
  }

  /**
   * STOP TYPING
   */
  async handleStopTyping(socket, { bookingId }) {
    try {
      socket.to(`booking_${bookingId}`).emit('user_stop_typing', {
        userId: socket.userId,
      });
    } catch (error) {
      console.error('Stop typing error:', error);
    }
  }

  /**
   * DISCONNECT
   * User disconnected
   */
  handleDisconnect(socket) {
    console.log(`User ${socket.userId} disconnected: ${socket.id}`);

    if (socket.bookingId) {
      socket.to(`booking_${socket.bookingId}`).emit('user_left', {
        userId: socket.userId,
        message: 'User left chat',
      });
    }
  }

  /**
   * OFFLINE NOTIFICATION
   * Send notification if receiver is offline
   */
  async sendOfflineNotification(bookingId, senderId) {
    try {
      const booking = await Booking.findById(bookingId);
      const receiverId =
        booking.customer_id.toString() === senderId
          ? booking.provider_id
          : booking.customer_id;

      // Check if user is online
      const sockets = await this.io.in(`booking_${bookingId}`).fetchSockets();
      const receiverOnline = sockets.some(
        (s) => s.userId.toString() === receiverId.toString()
      );

      // If offline, save notification
      if (!receiverOnline) {
        const Notification = require('../models/Notification');
        await Notification.create({
          user_id: receiverId,
          type: 'new_message',
          title: 'New message',
          message: 'You have a new message from a service provider',
          related_booking_id: bookingId,
          is_read: false,
        });
      }
    } catch (error) {
      console.error('Offline notification error:', error);
    }
  }

  /**
   * BROADCAST METHOD
   * Send message to specific user
   */
  async sendToUser(userId, event, data) {
    const sockets = await this.io.fetchSockets();
    const userSockets = sockets.filter((s) => s.userId === userId);
    userSockets.forEach((socket) => {
      socket.emit(event, data);
    });
  }

  /**
   * BROADCAST TO ROOM
   */
  broadcastToRoom(roomId, event, data) {
    this.io.to(roomId).emit(event, data);
  }
}

module.exports = SocketHandler;
```

### 2. Express Server Integration

**File: src/app.js**

```javascript
const express = require('express');
const http = require('http');
const SocketHandler = require('./socket/socketHandler');
const chatRoutes = require('./routes/chat');

const app = express();
const server = http.createServer(app);

// Initialize Socket.io
const socketHandler = new SocketHandler(server);

// Middleware
app.use(express.json());
app.use(express.cors());

// Routes
app.use('/api/v1/chat', chatRoutes);

// Start server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

module.exports = { app, server, socketHandler };
```

### 3. Chat Routes (HTTP Endpoints)

**File: src/routes/chat.js**

```javascript
const express = require('express');
const router = express.Router();
const { Message, Booking } = require('../models');
const { authenticate } = require('../middleware/auth');

/**
 * GET /api/v1/chat/:bookingId
 * Get all messages for a booking
 */
router.get('/:bookingId', authenticate, async (req, res) => {
  try {
    const { bookingId } = req.params;
    const userId = req.user.id;

    // Verify access
    const booking = await Booking.findById(bookingId);
    if (!booking) {
      return res.status(404).json({ success: false, message: 'Booking not found' });
    }

    if (
      booking.customer_id.toString() !== userId &&
      booking.provider_id.toString() !== userId
    ) {
      return res.status(403).json({ success: false, message: 'Unauthorized' });
    }

    // Fetch messages with pagination
    const page = req.query.page || 1;
    const limit = 50;
    const skip = (page - 1) * limit;

    const messages = await Message.find({ booking_id: bookingId })
      .sort({ created_at: -1 })
      .skip(skip)
      .limit(limit)
      .populate('sender_id', 'name profile_photo_url');

    const total = await Message.countDocuments({ booking_id: bookingId });

    res.status(200).json({
      success: true,
      data: {
        messages: messages.reverse(),
        pagination: {
          current: page,
          total: Math.ceil(total / limit),
          perPage: limit,
        },
      },
    });
  } catch (error) {
    console.error('Get messages error:', error);
    res.status(500).json({ success: false, message: error.message });
  }
});

/**
 * POST /api/v1/chat/mark-read/:bookingId
 * Mark all messages as read
 */
router.post('/mark-read/:bookingId', authenticate, async (req, res) => {
  try {
    const { bookingId } = req.params;

    await Message.updateMany(
      { booking_id: bookingId, receiver_id: req.user.id, is_read: false },
      { is_read: true }
    );

    res.status(200).json({
      success: true,
      message: 'Messages marked as read',
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

/**
 * GET /api/v1/chat/conversations
 * Get user's recent conversations
 */
router.get('/', authenticate, async (req, res) => {
  try {
    const userId = req.user.id;

    // Find all bookings user is part of
    const bookings = await Booking.find({
      $or: [
        { customer_id: userId },
        { provider_id: userId },
      ],
    })
      .select('_id customer_id provider_id status')
      .lean();

    // Get latest message from each booking
    const conversations = await Promise.all(
      bookings.map(async (booking) => {
        const lastMessage = await Message.findOne({ booking_id: booking._id })
          .sort({ created_at: -1 })
          .populate('sender_id', 'name profile_photo_url');

        const unreadCount = await Message.countDocuments({
          booking_id: booking._id,
          receiver_id: userId,
          is_read: false,
        });

        return {
          bookingId: booking._id,
          otherUserId:
            booking.customer_id.toString() === userId
              ? booking.provider_id
              : booking.customer_id,
          lastMessage: lastMessage?.message_text || '',
          lastMessageTime: lastMessage?.created_at,
          unreadCount: unreadCount,
          bookingStatus: booking.status,
        };
      })
    );

    // Sort by last message time
    conversations.sort(
      (a, b) => new Date(b.lastMessageTime) - new Date(a.lastMessageTime)
    );

    res.status(200).json({
      success: true,
      data: conversations,
    });
  } catch (error) {
    console.error('Get conversations error:', error);
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
```

---

## FRONTEND IMPLEMENTATION

### 1. Chat Service (React Hook)

**File: src/hooks/useChat.js**

```javascript
import { useState, useEffect, useRef, useCallback } from 'react';
import io from 'socket.io-client';
import axios from 'axios';

const useChat = (bookingId, token) => {
  const [messages, setMessages] = useState([]);
  const [isTyping, setIsTyping] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState(null);
  const socketRef = useRef(null);
  const typingTimeoutRef = useRef(null);

  /**
   * Initialize socket connection
   */
  useEffect(() => {
    // Create socket connection
    socketRef.current = io(process.env.REACT_APP_API_URL, {
      auth: {
        token: token,
      },
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
      reconnectionAttempts: 5,
    });

    // Connection established
    socketRef.current.on('connection_established', (data) => {
      console.log('Connected to chat server');
      setIsConnected(true);
      // Join the booking chat
      socketRef.current.emit('join_chat', { bookingId });
    });

    // Receive chat history
    socketRef.current.on('chat_history', (data) => {
      setMessages(data.messages);
    });

    // Receive new message
    socketRef.current.on('new_message', (message) => {
      setMessages((prev) => [...prev, message]);
    });

    // Message read receipt
    socketRef.current.on('message_read', (data) => {
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === data.messageId ? { ...msg, is_read: true } : msg
        )
      );
    });

    // User typing
    socketRef.current.on('user_typing', () => {
      setIsTyping(true);
    });

    // User stopped typing
    socketRef.current.on('user_stop_typing', () => {
      setIsTyping(false);
    });

    // Error handler
    socketRef.current.on('error', (data) => {
      setError(data.message);
    });

    // Disconnect handler
    socketRef.current.on('disconnect', () => {
      setIsConnected(false);
    });

    return () => {
      socketRef.current?.disconnect();
    };
  }, [bookingId, token]);

  /**
   * SEND MESSAGE
   */
  const sendMessage = useCallback(
    (messageText) => {
      if (!isConnected || !messageText.trim()) {
        setError('Not connected or message is empty');
        return;
      }

      socketRef.current.emit('send_message', {
        bookingId,
        messageText: messageText.trim(),
      });

      // Stop typing indicator
      socketRef.current.emit('stop_typing', { bookingId });
    },
    [bookingId, isConnected]
  );

  /**
   * TYPING INDICATOR
   */
  const handleTyping = useCallback(() => {
    if (!isConnected) return;

    socketRef.current.emit('typing', { bookingId });

    // Clear previous timeout
    clearTimeout(typingTimeoutRef.current);

    // Set new timeout to stop typing
    typingTimeoutRef.current = setTimeout(() => {
      socketRef.current.emit('stop_typing', { bookingId });
    }, 1000);
  }, [bookingId, isConnected]);

  /**
   * MARK AS READ
   */
  const markAsRead = useCallback(
    (messageId) => {
      socketRef.current.emit('read_message', { messageId, bookingId });
    },
    [bookingId]
  );

  return {
    messages,
    isTyping,
    isConnected,
    error,
    sendMessage,
    handleTyping,
    markAsRead,
  };
};

export default useChat;
```

### 2. Chat Component (React)

**File: src/components/ChatWindow.jsx**

```javascript
import React, { useState, useEffect, useRef } from 'react';
import useChat from '../hooks/useChat';
import './ChatWindow.css';

const ChatWindow = ({ bookingId, token, otherUserName, otherUserPhoto }) => {
  const [messageInput, setMessageInput] = useState('');
  const messagesEndRef = useRef(null);
  const { messages, isTyping, isConnected, error, sendMessage, handleTyping, markAsRead } =
    useChat(bookingId, token);

  /**
   * Auto-scroll to bottom when new message arrives
   */
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  /**
   * Mark messages as read when displayed
   */
  useEffect(() => {
    messages.forEach((msg) => {
      if (!msg.is_read && msg.receiver_id === localStorage.getItem('userId')) {
        markAsRead(msg.id);
      }
    });
  }, [messages, markAsRead]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  /**
   * Handle send message
   */
  const handleSendMessage = (e) => {
    e.preventDefault();
    if (messageInput.trim()) {
      sendMessage(messageInput);
      setMessageInput('');
    }
  };

  /**
   * Handle typing
   */
  const handleInputChange = (e) => {
    setMessageInput(e.target.value);
    handleTyping();
  };

  if (!isConnected) {
    return (
      <div className="chat-container loading">
        <div className="connection-status">Connecting to chat...</div>
      </div>
    );
  }

  return (
    <div className="chat-container">
      {/* Chat Header */}
      <div className="chat-header">
        <div className="chat-user-info">
          <img src={otherUserPhoto} alt={otherUserName} className="user-avatar" />
          <div className="user-details">
            <h3>{otherUserName}</h3>
            <span className="status">{isConnected ? 'Online' : 'Offline'}</span>
          </div>
        </div>
        <div className="chat-actions">
          <button className="btn-icon">☎️</button>
          <button className="btn-icon">ℹ️</button>
        </div>
      </div>

      {/* Messages */}
      <div className="messages-container">
        {messages.length === 0 ? (
          <div className="empty-chat">
            <p>No messages yet. Start the conversation!</p>
          </div>
        ) : (
          messages.map((msg) => (
            <div
              key={msg.id}
              className={`message-bubble ${
                msg.sender_id._id === localStorage.getItem('userId')
                  ? 'sent'
                  : 'received'
              }`}
            >
              <div className="message-content">
                {msg.message_text}
              </div>
              <div className="message-time">
                {new Date(msg.created_at).toLocaleTimeString([], {
                  hour: '2-digit',
                  minute: '2-digit',
                })}
                {msg.sender_id._id === localStorage.getItem('userId') &&
                  (msg.is_read ? '✓✓' : '✓')}
              </div>
            </div>
          ))
        )}

        {/* Typing Indicator */}
        {isTyping && (
          <div className="message-bubble received typing">
            <div className="typing-indicator">
              <span></span>
              <span></span>
              <span></span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Error Message */}
      {error && <div className="chat-error">{error}</div>}

      {/* Input */}
      <form onSubmit={handleSendMessage} className="chat-input-form">
        <input
          type="text"
          placeholder="Type a message..."
          value={messageInput}
          onChange={handleInputChange}
          disabled={!isConnected}
          className="chat-input"
        />
        <button
          type="submit"
          disabled={!isConnected || !messageInput.trim()}
          className="btn-send"
        >
          📤
        </button>
      </form>
    </div>
  );
};

export default ChatWindow;
```

### 3. Chat Styling

**File: src/components/ChatWindow.css**

```css
.chat-container {
  display: flex;
  flex-direction: column;
  height: 100%;
  background: white;
  border-radius: 10px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.chat-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem;
  border-bottom: 1px solid #eee;
  background: white;
}

.chat-user-info {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.user-avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  object-fit: cover;
}

.user-details h3 {
  margin: 0;
  font-size: 14px;
  font-weight: 600;
}

.status {
  font-size: 12px;
  color: #999;
}

.chat-actions {
  display: flex;
  gap: 0.5rem;
}

.btn-icon {
  background: none;
  border: none;
  font-size: 18px;
  cursor: pointer;
  padding: 8px;
}

.messages-container {
  flex: 1;
  overflow-y: auto;
  padding: 1rem;
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.empty-chat {
  text-align: center;
  color: #999;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
}

.message-bubble {
  display: flex;
  flex-direction: column;
  max-width: 70%;
  word-wrap: break-word;
}

.message-bubble.sent {
  align-self: flex-end;
  align-items: flex-end;
}

.message-bubble.sent .message-content {
  background: #FF6B35;
  color: white;
  border-radius: 18px 18px 4px 18px;
}

.message-bubble.received {
  align-self: flex-start;
  align-items: flex-start;
}

.message-bubble.received .message-content {
  background: #f0f0f0;
  color: #333;
  border-radius: 18px 18px 18px 4px;
}

.message-content {
  padding: 10px 16px;
  font-size: 14px;
  line-height: 1.4;
}

.message-time {
  font-size: 11px;
  color: #999;
  margin-top: 4px;
  padding: 0 12px;
}

.message-bubble.sent .message-time {
  color: #666;
}

.typing {
  align-self: flex-start;
}

.typing-indicator {
  display: flex;
  gap: 4px;
  padding: 10px 16px;
}

.typing-indicator span {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #999;
  animation: typing 1.4s infinite;
}

.typing-indicator span:nth-child(2) {
  animation-delay: 0.2s;
}

.typing-indicator span:nth-child(3) {
  animation-delay: 0.4s;
}

@keyframes typing {
  0%, 60%, 100% {
    opacity: 0.5;
  }
  30% {
    opacity: 1;
  }
}

.chat-input-form {
  display: flex;
  gap: 0.5rem;
  padding: 1rem;
  border-top: 1px solid #eee;
  background: white;
}

.chat-input {
  flex: 1;
  padding: 10px 16px;
  border: 1px solid #ddd;
  border-radius: 20px;
  font-size: 14px;
  outline: none;
  resize: none;
}

.chat-input:focus {
  border-color: #FF6B35;
  box-shadow: 0 0 0 3px rgba(255, 107, 53, 0.1);
}

.btn-send {
  background: #FF6B35;
  color: white;
  border: none;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  cursor: pointer;
  font-size: 18px;
  transition: background 0.2s;
}

.btn-send:hover:not(:disabled) {
  background: #E55A24;
}

.btn-send:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.chat-error {
  background: #ffe0e0;
  color: #c33;
  padding: 1rem;
  margin: 0.5rem;
  border-radius: 6px;
  font-size: 13px;
}

.loading {
  align-items: center;
  justify-content: center;
}

.connection-status {
  text-align: center;
  color: #666;
  font-size: 14px;
}

/* Mobile responsive */
@media (max-width: 768px) {
  .message-bubble {
    max-width: 90%;
  }
}
```

---

## SOCKET EVENTS

### Events Emitted by Client

```javascript
// Join chat room
socket.emit('join_chat', { bookingId })

// Send message
socket.emit('send_message', {
  bookingId: string,
  messageText: string
})

// Mark message as read
socket.emit('read_message', {
  messageId: string,
  bookingId: string
})

// User is typing
socket.emit('typing', { bookingId })

// User stopped typing
socket.emit('stop_typing', { bookingId })
```

### Events Received by Client

```javascript
// Connection established
socket.on('connection_established', { message, socketId })

// Chat history loaded
socket.on('chat_history', { messages })

// New message received
socket.on('new_message', {
  id, sender_id, message_text, created_at, is_read
})

// Message read receipt
socket.on('message_read', { messageId, timestamp })

// User typing
socket.on('user_typing', { userId })

// User stopped typing
socket.on('user_stop_typing', { userId })

// Message sent confirmation
socket.on('message_sent', { id, status })

// Error
socket.on('error', { message })
```

---

## MESSAGE PERSISTENCE

### Message Model

**File: src/models/Message.js**

```javascript
const mongoose = require('mongoose');

const messageSchema = new mongoose.Schema({
  booking_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Booking',
    required: true,
    index: true,
  },
  sender_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  receiver_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  message_text: {
    type: String,
    required: true,
    maxlength: 1000,
  },
  is_read: {
    type: Boolean,
    default: false,
    index: true,
  },
  created_at: {
    type: Date,
    default: Date.now,
    index: true,
  },
  updated_at: {
    type: Date,
    default: Date.now,
  },
});

// Index for faster queries
messageSchema.index({ booking_id: 1, created_at: -1 });
messageSchema.index({ receiver_id: 1, is_read: 1 });

module.exports = mongoose.model('Message', messageSchema);
```

---

## SCALABILITY

### Horizontal Scaling with Redis Adapter

```javascript
// Multiple servers can connect to same Redis instance
const redis = require('redis');
const { createAdapter } = require('@socket.io/redis-adapter');

const pubClient = redis.createClient();
const subClient = pubClient.duplicate();

Promise.all([pubClient.connect(), subClient.connect()]).then(() => {
  io.adapter(createAdapter(pubClient, subClient));
});
```

### Load Balancing with Sticky Sessions

```javascript
// Nginx configuration
upstream backend {
  server 127.0.0.1:3000;
  server 127.0.0.1:3001;
  server 127.0.0.1:3002;
}

server {
  location /socket.io {
    proxy_pass http://backend;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_read_timeout 86400;
  }
}
```

---

## SECURITY

### Authentication & Authorization

```javascript
// Verify JWT token before allowing connection
io.use((socket, next) => {
  const token = socket.handshake.auth.token;
  
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    socket.userId = decoded.id;
    next();
  } catch (error) {
    next(new Error('Authentication failed'));
  }
});

// Verify access to booking
async function verifyBookingAccess(userId, bookingId) {
  const booking = await Booking.findById(bookingId);
  return (
    booking.customer_id.toString() === userId ||
    booking.provider_id.toString() === userId
  );
}
```

### Rate Limiting

```javascript
const socketIO = require('socket.io');
const { limiter } = require('./middleware/rateLimit');

io.use((socket, next) => {
  limiter(socket.handshake.address, next);
});
```

### Input Validation

```javascript
const validateMessage = (message) => {
  // Check length
  if (!message || message.length === 0 || message.length > 1000) {
    return false;
  }
  
  // Check for malicious content
  if (/<script|javascript:/i.test(message)) {
    return false;
  }
  
  return true;
};
```

---

## MONITORING & DEBUGGING

### Socket.io Adapter Stats

```javascript
setInterval(() => {
  const rooms = io.of('/').adapter.rooms;
  const sockets = io.of('/').adapter.sids;
  
  console.log(`Total connections: ${sockets.size}`);
  console.log(`Active rooms: ${rooms.size}`);
}, 10000);
```

### Error Logging

```javascript
socket.on('connect_error', (error) => {
  console.error('Client connection error:', error);
  logError({
    type: 'socket_connection_error',
    userId: socket.userId,
    error: error.message,
    timestamp: new Date(),
  });
});
```

---

## TESTING SOCKET.IO

### Jest Tests

```javascript
const { createServer } = require('http');
const { Server } = require('socket.io');
const Client = require('socket.io-client');

describe('Chat Socket Tests', () => {
  let io, serverSocket, clientSocket;

  beforeAll((done) => {
    const httpServer = createServer();
    io = new Server(httpServer);
    httpServer.listen(() => {
      const port = httpServer.address().port;
      clientSocket = new Client(`http://localhost:${port}`);
      io.on('connection', (socket) => {
        serverSocket = socket;
      });
      clientSocket.on('connect', done);
    });
  });

  afterAll(() => {
    io.close();
    clientSocket.close();
  });

  test('should send and receive message', (done) => {
    clientSocket.emit('send_message', { message: 'hello' });
    serverSocket.on('send_message', (data) => {
      expect(data.message).toBe('hello');
      done();
    });
  });
});
```

