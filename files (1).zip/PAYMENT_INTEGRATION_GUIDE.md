# AYARSHI - Payment Integration Guide

## Table of Contents
1. [Razorpay Integration](#razorpay-integration)
2. [Stripe Integration](#stripe-integration)
3. [Payment Flow](#payment-flow)
4. [Error Handling](#error-handling)
5. [Security](#security)

---

## RAZORPAY INTEGRATION

### Installation
```bash
npm install razorpay axios dotenv
```

### Environment Variables (.env)
```
RAZORPAY_KEY_ID=rzp_live_xxxxxxxxxxxx
RAZORPAY_KEY_SECRET=xxxxxxxxxxxxxxxx
RAZORPAY_WEBHOOK_SECRET=xxxxxxxxxxxxxxxx
APP_URL=https://yourdomain.com
```

### 1. Backend Setup - Payment Service

**File: src/services/paymentService.js**

```javascript
const Razorpay = require('razorpay');
const axios = require('axios');
const crypto = require('crypto');
const { Payment, Booking } = require('../models');

class PaymentService {
  constructor() {
    this.razorpay = new Razorpay({
      key_id: process.env.RAZORPAY_KEY_ID,
      key_secret: process.env.RAZORPAY_KEY_SECRET,
    });
  }

  /**
   * CREATE ORDER - Step 1
   * Initiates payment by creating an order
   */
  async createOrder(bookingId, amount, customerId, providerId) {
    try {
      // Validate booking exists
      const booking = await Booking.findById(bookingId);
      if (!booking) {
        throw new Error('Booking not found');
      }

      // Create Razorpay order
      const orderParams = {
        amount: Math.round(amount * 100), // Convert to paise
        currency: 'INR',
        receipt: `booking_${bookingId}`,
        notes: {
          booking_id: bookingId,
          customer_id: customerId,
          provider_id: providerId,
        },
      };

      const order = await this.razorpay.orders.create(orderParams);

      // Save order details in database
      const payment = await Payment.create({
        booking_id: bookingId,
        customer_id: customerId,
        provider_id: providerId,
        amount: amount,
        currency: 'INR',
        razorpay_order_id: order.id,
        status: 'pending',
        payment_method: 'razorpay',
      });

      return {
        success: true,
        orderId: order.id,
        amount: order.amount,
        currency: order.currency,
        key: process.env.RAZORPAY_KEY_ID,
        customerEmail: customerId, // Pass customer email
      };
    } catch (error) {
      console.error('Order creation error:', error);
      throw error;
    }
  }

  /**
   * VERIFY PAYMENT - Step 2
   * Verifies payment signature after successful payment
   */
  async verifyPayment(razorpayOrderId, razorpayPaymentId, razorpaySignature) {
    try {
      // Create signature body
      const signatureBody = `${razorpayOrderId}|${razorpayPaymentId}`;

      // Generate signature
      const expectedSignature = crypto
        .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
        .update(signatureBody)
        .digest('hex');

      // Verify signature
      if (expectedSignature !== razorpaySignature) {
        throw new Error('Invalid payment signature');
      }

      // Fetch payment details from Razorpay API
      const paymentDetails = await this.razorpay.payments.fetch(razorpayPaymentId);

      if (paymentDetails.status !== 'captured') {
        throw new Error('Payment not captured');
      }

      // Update payment in database
      const payment = await Payment.findOneAndUpdate(
        { razorpay_order_id: razorpayOrderId },
        {
          razorpay_payment_id: razorpayPaymentId,
          razorpay_signature: razorpaySignature,
          status: 'success',
          updated_at: new Date(),
        },
        { new: true }
      );

      // Update booking payment status
      await Booking.findByIdAndUpdate(
        payment.booking_id,
        { payment_status: 'paid' },
        { new: true }
      );

      return {
        success: true,
        payment: payment,
        message: 'Payment verified successfully',
      };
    } catch (error) {
      console.error('Payment verification error:', error);
      throw error;
    }
  }

  /**
   * GET PAYMENT DETAILS
   * Retrieve payment information
   */
  async getPaymentDetails(bookingId) {
    try {
      const payment = await Payment.findOne({ booking_id: bookingId });
      if (!payment) {
        throw new Error('Payment not found');
      }
      return payment;
    } catch (error) {
      console.error('Error fetching payment details:', error);
      throw error;
    }
  }

  /**
   * REFUND PAYMENT
   * Process refund for cancelled booking
   */
  async refundPayment(bookingId, amount, reason) {
    try {
      const payment = await Payment.findOne({ booking_id: bookingId });

      if (!payment || !payment.razorpay_payment_id) {
        throw new Error('Payment not found or invalid');
      }

      // Create refund
      const refund = await this.razorpay.payments.refund(
        payment.razorpay_payment_id,
        {
          amount: Math.round(amount * 100), // Convert to paise
          notes: {
            booking_id: bookingId,
            reason: reason,
          },
        }
      );

      // Update payment status
      await Payment.findByIdAndUpdate(
        payment._id,
        {
          status: 'refunded',
          refund_id: refund.id,
          refund_amount: amount,
          updated_at: new Date(),
        }
      );

      return {
        success: true,
        refund: refund,
        message: 'Refund processed successfully',
      };
    } catch (error) {
      console.error('Refund error:', error);
      throw error;
    }
  }

  /**
   * WEBHOOK HANDLER
   * Process Razorpay webhook events
   */
  async handleWebhook(event, signature) {
    try {
      // Verify webhook signature
      const shasum = crypto.createHmac('sha256', process.env.RAZORPAY_WEBHOOK_SECRET);
      shasum.update(JSON.stringify(event));
      const digest = shasum.digest('hex');

      if (digest !== signature) {
        throw new Error('Invalid webhook signature');
      }

      // Handle different webhook events
      switch (event.event) {
        case 'payment.authorized':
          await this.handlePaymentAuthorized(event.payload.payment.entity);
          break;

        case 'payment.failed':
          await this.handlePaymentFailed(event.payload.payment.entity);
          break;

        case 'refund.created':
          await this.handleRefundCreated(event.payload.refund.entity);
          break;

        case 'refund.failed':
          await this.handleRefundFailed(event.payload.refund.entity);
          break;

        default:
          console.log(`Unhandled event: ${event.event}`);
      }

      return { success: true };
    } catch (error) {
      console.error('Webhook handling error:', error);
      throw error;
    }
  }

  async handlePaymentAuthorized(paymentEntity) {
    // Payment authorized but needs capture
    console.log('Payment authorized:', paymentEntity.id);
  }

  async handlePaymentFailed(paymentEntity) {
    // Update payment status to failed
    await Payment.findOneAndUpdate(
      { razorpay_payment_id: paymentEntity.id },
      { status: 'failed' }
    );
  }

  async handleRefundCreated(refundEntity) {
    // Update refund status
    await Payment.findOneAndUpdate(
      { refund_id: refundEntity.id },
      { status: 'refunded' }
    );
  }

  async handleRefundFailed(refundEntity) {
    console.error('Refund failed:', refundEntity.id);
  }
}

module.exports = new PaymentService();
```

### 2. Backend Routes - Payment Endpoints

**File: src/routes/payments.js**

```javascript
const express = require('express');
const router = express.Router();
const paymentService = require('../services/paymentService');
const { authenticate } = require('../middleware/auth');
const { validatePayment } = require('../middleware/validation');

/**
 * POST /api/v1/payments/create-order
 * Create payment order for booking
 */
router.post('/create-order', authenticate, async (req, res) => {
  try {
    const { bookingId, amount } = req.body;
    const customerId = req.user.id;

    // Validate request
    if (!bookingId || !amount) {
      return res.status(400).json({
        success: false,
        message: 'Missing required fields: bookingId, amount',
      });
    }

    // Create order
    const order = await paymentService.createOrder(
      bookingId,
      amount,
      customerId,
      null
    );

    res.status(200).json({
      success: true,
      data: order,
    });
  } catch (error) {
    console.error('Create order error:', error);
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
});

/**
 * POST /api/v1/payments/verify
 * Verify payment after successful transaction
 */
router.post('/verify', authenticate, async (req, res) => {
  try {
    const { razorpayOrderId, razorpayPaymentId, razorpaySignature } = req.body;

    // Validate request
    if (!razorpayOrderId || !razorpayPaymentId || !razorpaySignature) {
      return res.status(400).json({
        success: false,
        message: 'Missing payment verification fields',
      });
    }

    // Verify payment
    const result = await paymentService.verifyPayment(
      razorpayOrderId,
      razorpayPaymentId,
      razorpaySignature
    );

    res.status(200).json({
      success: true,
      message: 'Payment verified successfully',
      data: result,
    });
  } catch (error) {
    console.error('Payment verification error:', error);
    res.status(400).json({
      success: false,
      message: error.message,
    });
  }
});

/**
 * GET /api/v1/payments/:bookingId
 * Get payment details for a booking
 */
router.get('/:bookingId', authenticate, async (req, res) => {
  try {
    const { bookingId } = req.params;

    const payment = await paymentService.getPaymentDetails(bookingId);

    res.status(200).json({
      success: true,
      data: payment,
    });
  } catch (error) {
    res.status(404).json({
      success: false,
      message: error.message,
    });
  }
});

/**
 * POST /api/v1/payments/refund
 * Refund payment for cancelled booking
 */
router.post('/refund', authenticate, async (req, res) => {
  try {
    const { bookingId, amount, reason } = req.body;

    // Validate request
    if (!bookingId || !amount || !reason) {
      return res.status(400).json({
        success: false,
        message: 'Missing required fields',
      });
    }

    const refund = await paymentService.refundPayment(bookingId, amount, reason);

    res.status(200).json({
      success: true,
      data: refund,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
});

/**
 * POST /api/v1/payments/webhook
 * Razorpay webhook endpoint
 */
router.post('/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  try {
    const signature = req.headers['x-razorpay-signature'];
    const event = JSON.parse(req.body);

    await paymentService.handleWebhook(event, signature);

    res.status(200).json({ success: true });
  } catch (error) {
    console.error('Webhook error:', error);
    res.status(400).json({
      success: false,
      message: error.message,
    });
  }
});

module.exports = router;
```

### 3. Frontend Implementation - React

**File: src/components/PaymentCheckout.jsx**

```javascript
import React, { useState } from 'react';
import axios from 'axios';

const PaymentCheckout = ({ bookingId, amount, onSuccess, onError }) => {
  const [loading, setLoading] = useState(false);

  /**
   * Load Razorpay script dynamically
   */
  const loadRazorpay = async () => {
    return new Promise((resolve) => {
      const script = document.createElement('script');
      script.src = 'https://checkout.razorpay.com/v1/checkout.js';
      script.onload = () => resolve(true);
      script.onerror = () => resolve(false);
      document.body.appendChild(script);
    });
  };

  /**
   * Handle payment initiation
   */
  const handlePaymentClick = async () => {
    try {
      setLoading(true);

      // Step 1: Create order on backend
      const orderResponse = await axios.post(
        '/api/v1/payments/create-order',
        {
          bookingId,
          amount,
        },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`,
          },
        }
      );

      if (!orderResponse.data.success) {
        throw new Error('Failed to create order');
      }

      // Step 2: Load Razorpay script
      const isRazorpayLoaded = await loadRazorpay();
      if (!isRazorpayLoaded) {
        throw new Error('Failed to load Razorpay');
      }

      const { orderId, amount: orderAmount, key } = orderResponse.data.data;

      // Step 3: Open Razorpay checkout
      const options = {
        key: key,
        amount: orderAmount,
        currency: 'INR',
        name: 'AYARSHI',
        description: `Booking #${bookingId}`,
        order_id: orderId,
        handler: (response) => {
          handlePaymentSuccess(response);
        },
        prefill: {
          name: localStorage.getItem('userName'),
          email: localStorage.getItem('userEmail'),
          contact: localStorage.getItem('userPhone'),
        },
        theme: {
          color: '#FF6B35',
        },
        modal: {
          ondismiss: () => {
            setLoading(false);
            onError && onError('Payment cancelled by user');
          },
        },
      };

      const razorpay = new window.Razorpay(options);
      razorpay.open();
    } catch (error) {
      console.error('Payment error:', error);
      setLoading(false);
      onError && onError(error.message);
    }
  };

  /**
   * Handle successful payment
   */
  const handlePaymentSuccess = async (response) => {
    try {
      // Step 4: Verify payment on backend
      const verifyResponse = await axios.post(
        '/api/v1/payments/verify',
        {
          razorpayOrderId: response.razorpay_order_id,
          razorpayPaymentId: response.razorpay_payment_id,
          razorpaySignature: response.razorpay_signature,
        },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`,
          },
        }
      );

      if (verifyResponse.data.success) {
        setLoading(false);
        onSuccess && onSuccess(verifyResponse.data.data);
      } else {
        throw new Error('Payment verification failed');
      }
    } catch (error) {
      console.error('Verification error:', error);
      setLoading(false);
      onError && onError(error.message);
    }
  };

  return (
    <div className="payment-checkout">
      <div className="payment-details">
        <h3>Payment Details</h3>
        <div className="detail-row">
          <span>Booking ID:</span>
          <span>{bookingId}</span>
        </div>
        <div className="detail-row">
          <span>Amount:</span>
          <span className="amount">₹{amount}</span>
        </div>
      </div>

      <button
        onClick={handlePaymentClick}
        disabled={loading}
        className="btn-pay"
      >
        {loading ? 'Processing...' : `Pay ₹${amount}`}
      </button>

      <p className="payment-note">
        💳 You will be redirected to Razorpay's secure payment gateway
      </p>
    </div>
  );
};

export default PaymentCheckout;
```

---

## STRIPE INTEGRATION

### Installation
```bash
npm install stripe axios dotenv
```

### Environment Variables
```
STRIPE_PUBLIC_KEY=pk_live_xxxxxxxxxxxxxxxx
STRIPE_SECRET_KEY=sk_live_xxxxxxxxxxxxxxxx
STRIPE_WEBHOOK_SECRET=whsec_xxxxxxxxxxxxxxxx
```

### Payment Service - Stripe

**File: src/services/stripePaymentService.js**

```javascript
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const { Payment, Booking } = require('../models');

class StripePaymentService {
  /**
   * CREATE PAYMENT INTENT
   * Create Stripe Payment Intent for payment
   */
  async createPaymentIntent(bookingId, amount, customerId, providerEmail) {
    try {
      const booking = await Booking.findById(bookingId);
      if (!booking) {
        throw new Error('Booking not found');
      }

      // Create payment intent
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: 'inr',
        description: `Service Booking #${bookingId}`,
        metadata: {
          booking_id: bookingId,
          customer_id: customerId,
          provider_id: booking.provider_id,
        },
        receipt_email: customerId,
      });

      // Save to database
      const payment = await Payment.create({
        booking_id: bookingId,
        customer_id: customerId,
        provider_id: booking.provider_id,
        amount: amount,
        currency: 'INR',
        stripe_payment_intent_id: paymentIntent.id,
        status: 'pending',
        payment_method: 'stripe',
      });

      return {
        success: true,
        clientSecret: paymentIntent.client_secret,
        paymentIntentId: paymentIntent.id,
      };
    } catch (error) {
      console.error('Payment intent error:', error);
      throw error;
    }
  }

  /**
   * CONFIRM PAYMENT
   * Confirm payment intent after client-side processing
   */
  async confirmPayment(paymentIntentId) {
    try {
      const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);

      if (paymentIntent.status !== 'succeeded') {
        throw new Error('Payment not succeeded');
      }

      // Update payment in database
      const payment = await Payment.findOneAndUpdate(
        { stripe_payment_intent_id: paymentIntentId },
        {
          status: 'success',
          stripe_charge_id: paymentIntent.charges.data[0].id,
          updated_at: new Date(),
        },
        { new: true }
      );

      // Update booking
      await Booking.findByIdAndUpdate(
        payment.booking_id,
        { payment_status: 'paid' },
        { new: true }
      );

      return {
        success: true,
        payment: payment,
      };
    } catch (error) {
      console.error('Payment confirmation error:', error);
      throw error;
    }
  }

  /**
   * REFUND PAYMENT
   */
  async refundPayment(paymentIntentId, amount, reason) {
    try {
      const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);

      const refund = await stripe.refunds.create({
        charge: paymentIntent.charges.data[0].id,
        amount: Math.round(amount * 100),
        metadata: {
          reason: reason,
        },
      });

      // Update payment status
      await Payment.findOneAndUpdate(
        { stripe_payment_intent_id: paymentIntentId },
        {
          status: 'refunded',
          stripe_refund_id: refund.id,
          refund_amount: amount,
        }
      );

      return {
        success: true,
        refund: refund,
      };
    } catch (error) {
      console.error('Refund error:', error);
      throw error;
    }
  }

  /**
   * WEBHOOK HANDLER
   */
  async handleWebhook(event, signature) {
    try {
      // Verify webhook signature
      const webhookEvent = stripe.webhooks.constructEvent(
        JSON.stringify(event),
        signature,
        process.env.STRIPE_WEBHOOK_SECRET
      );

      switch (webhookEvent.type) {
        case 'payment_intent.succeeded':
          await this.handlePaymentSucceeded(webhookEvent.data.object);
          break;

        case 'payment_intent.payment_failed':
          await this.handlePaymentFailed(webhookEvent.data.object);
          break;

        case 'charge.refunded':
          await this.handleRefunded(webhookEvent.data.object);
          break;

        default:
          console.log(`Unhandled event type: ${webhookEvent.type}`);
      }

      return { success: true };
    } catch (error) {
      console.error('Webhook error:', error);
      throw error;
    }
  }

  async handlePaymentSucceeded(paymentIntent) {
    await Payment.findOneAndUpdate(
      { stripe_payment_intent_id: paymentIntent.id },
      { status: 'success' }
    );
  }

  async handlePaymentFailed(paymentIntent) {
    await Payment.findOneAndUpdate(
      { stripe_payment_intent_id: paymentIntent.id },
      { status: 'failed' }
    );
  }

  async handleRefunded(charge) {
    await Payment.findOneAndUpdate(
      { stripe_charge_id: charge.id },
      { status: 'refunded' }
    );
  }
}

module.exports = new StripePaymentService();
```

### Frontend - Stripe with React

**File: src/components/StripePayment.jsx**

```javascript
import React, { useState, useEffect } from 'react';
import { CardElement, useStripe, useElements } from '@stripe/react-stripe-js';
import axios from 'axios';

const StripePayment = ({ bookingId, amount, onSuccess, onError }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [loading, setLoading] = useState(false);
  const [clientSecret, setClientSecret] = useState('');

  useEffect(() => {
    initializePayment();
  }, [bookingId, amount]);

  /**
   * Initialize payment intent on backend
   */
  const initializePayment = async () => {
    try {
      const response = await axios.post(
        '/api/v1/payments/create-payment-intent',
        { bookingId, amount },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`,
          },
        }
      );

      if (response.data.success) {
        setClientSecret(response.data.data.clientSecret);
      }
    } catch (error) {
      console.error('Error initializing payment:', error);
      onError && onError(error.message);
    }
  };

  /**
   * Handle payment submission
   */
  const handlePayment = async (e) => {
    e.preventDefault();

    if (!stripe || !elements || !clientSecret) {
      return;
    }

    setLoading(true);

    try {
      const cardElement = elements.getElement(CardElement);

      // Confirm payment
      const result = await stripe.confirmCardPayment(clientSecret, {
        payment_method: {
          card: cardElement,
          billing_details: {
            name: localStorage.getItem('userName'),
            email: localStorage.getItem('userEmail'),
          },
        },
      });

      if (result.error) {
        throw new Error(result.error.message);
      }

      if (result.paymentIntent.status === 'succeeded') {
        // Verify on backend
        const verifyResponse = await axios.post(
          '/api/v1/payments/confirm-stripe',
          { paymentIntentId: result.paymentIntent.id },
          {
            headers: {
              Authorization: `Bearer ${localStorage.getItem('token')}`,
            },
          }
        );

        setLoading(false);
        onSuccess && onSuccess(verifyResponse.data.data);
      }
    } catch (error) {
      console.error('Payment error:', error);
      setLoading(false);
      onError && onError(error.message);
    }
  };

  return (
    <form onSubmit={handlePayment} className="stripe-form">
      <div className="form-group">
        <label>Card Details</label>
        <div className="card-element">
          <CardElement
            options={{
              style: {
                base: {
                  fontSize: '16px',
                  color: '#424770',
                  '::placeholder': {
                    color: '#aab7c4',
                  },
                },
              },
            }}
          />
        </div>
      </div>

      <button type="submit" disabled={loading || !stripe}>
        {loading ? 'Processing...' : `Pay ₹${amount}`}
      </button>
    </form>
  );
};

export default StripePayment;
```

---

## PAYMENT FLOW DIAGRAM

```
CUSTOMER INITIATES BOOKING
        ↓
CREATE ORDER/PAYMENT INTENT
        ↓
SHOW PAYMENT UI (Razorpay/Stripe)
        ↓
CUSTOMER ENTERS PAYMENT DETAILS
        ↓
PAYMENT GATEWAY PROCESSES
        ↓
SUCCESS/FAILURE RESPONSE
        ↓
VERIFY PAYMENT SIGNATURE
        ↓
UPDATE DATABASE
        ↓
SEND CONFIRMATION EMAIL
        ↓
NOTIFY SERVICE PROVIDER
```

---

## ERROR HANDLING & RETRY LOGIC

```javascript
// Exponential backoff retry
async function retryPaymentVerification(paymentId, maxRetries = 3) {
  let lastError;
  
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await verifyPayment(paymentId);
    } catch (error) {
      lastError = error;
      // Exponential backoff: 1s, 2s, 4s
      await new Promise(resolve => 
        setTimeout(resolve, Math.pow(2, i) * 1000)
      );
    }
  }
  
  throw lastError;
}
```

---

## SECURITY BEST PRACTICES

1. **Never log sensitive data** (payment details, tokens)
2. **Always verify signatures** on backend
3. **Use HTTPS only** for payment endpoints
4. **Implement rate limiting** on payment endpoints
5. **Store encrypted tokens** in database
6. **Use webhooks** for async verification
7. **Implement idempotency** to prevent duplicate charges
8. **Regularly rotate API keys**
9. **Use PCI compliance tools** (Stripe/Razorpay handle this)
10. **Monitor suspicious activity** with anomaly detection

---

## TESTING PAYMENTS

### Razorpay Test Cards
```
Success: 4111 1111 1111 1111
Fail: 4111 1111 1111 1112
CVV: Any 3 digits
Date: Any future date
```

### Stripe Test Cards
```
Success: 4242 4242 4242 4242
Fail: 4000 0000 0000 0002
CVV: Any 3 digits
Date: Any future date
```

---

## PAYMENT STATUS CODES

```
pending       - Payment initiated, awaiting confirmation
processing    - Payment being processed
success       - Payment completed successfully
failed        - Payment failed
cancelled     - Payment cancelled by user
refunded      - Payment refunded
disputed      - Chargeback disputed
```

---

## WEBHOOKS CONFIGURATION

### Razorpay Webhook
```
Settings → Webhooks → Add New Webhook
URL: https://yourdomain.com/api/v1/payments/webhook
Events:
  - payment.authorized
  - payment.failed
  - refund.created
  - refund.failed
```

### Stripe Webhook
```
Dashboard → Developers → Webhooks → Add Endpoint
URL: https://yourdomain.com/api/v1/stripe/webhook
Events:
  - payment_intent.succeeded
  - payment_intent.payment_failed
  - charge.refunded
```

