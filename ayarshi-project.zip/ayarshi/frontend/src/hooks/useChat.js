import { useState, useEffect, useRef, useCallback } from 'react';
import { io } from 'socket.io-client';

const useChat = (bookingId) => {
  const [messages, setMessages] = useState([]);
  const [isTyping, setIsTyping] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState(null);
  const socketRef = useRef(null);
  const typingTimeoutRef = useRef(null);
  const token = localStorage.getItem('token');

  useEffect(() => {
    if (!bookingId || !token) return;

    socketRef.current = io(process.env.REACT_APP_API_URL || 'http://localhost:5000', {
      auth: { token },
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
      reconnectionAttempts: 5,
    });

    socketRef.current.on('connection_established', () => {
      setIsConnected(true);
      socketRef.current.emit('join_chat', { bookingId });
    });

    socketRef.current.on('chat_history', ({ messages }) => setMessages(messages));
    socketRef.current.on('new_message', (msg) => setMessages((prev) => [...prev, msg]));
    socketRef.current.on('message_read', ({ messageId }) => {
      setMessages((prev) =>
        prev.map((m) => (m.id === messageId || m._id === messageId ? { ...m, is_read: true } : m))
      );
    });
    socketRef.current.on('user_typing', () => setIsTyping(true));
    socketRef.current.on('user_stop_typing', () => setIsTyping(false));
    socketRef.current.on('error', ({ message }) => setError(message));
    socketRef.current.on('disconnect', () => setIsConnected(false));
    socketRef.current.on('connect_error', () => setIsConnected(false));

    return () => {
      socketRef.current?.disconnect();
    };
  }, [bookingId, token]);

  const sendMessage = useCallback(
    (messageText) => {
      if (!isConnected || !messageText?.trim()) return;
      socketRef.current.emit('send_message', { bookingId, messageText: messageText.trim() });
      socketRef.current.emit('stop_typing', { bookingId });
    },
    [bookingId, isConnected]
  );

  const handleTyping = useCallback(() => {
    if (!isConnected) return;
    socketRef.current.emit('typing', { bookingId });
    clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(() => {
      socketRef.current.emit('stop_typing', { bookingId });
    }, 1500);
  }, [bookingId, isConnected]);

  const markAsRead = useCallback(
    (messageId) => {
      socketRef.current?.emit('read_message', { messageId, bookingId });
    },
    [bookingId]
  );

  return { messages, isTyping, isConnected, error, sendMessage, handleTyping, markAsRead };
};

export default useChat;
