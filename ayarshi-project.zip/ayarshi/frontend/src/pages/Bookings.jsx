import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import api from '../api/axios';

const statusBadge = (status) => {
  const map = { pending: 'badge-yellow', confirmed: 'badge-blue', in_progress: 'badge-orange', completed: 'badge-green', cancelled: 'badge-gray' };
  return <span className={`badge ${map[status] || 'badge-gray'}`}>{status.replace('_', ' ')}</span>;
};

export default function Bookings() {
  const { user } = useAuth();
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ provider_id: '', service_name: '', description: '', amount: '', scheduled_at: '' });
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    api.get('/api/v1/bookings').then((res) => setBookings(res.data.data || [])).finally(() => setLoading(false));
  }, []);

  const handleCreate = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await api.post('/api/v1/bookings', form);
      setBookings([res.data.data, ...bookings]);
      setShowForm(false);
      setForm({ provider_id: '', service_name: '', description: '', amount: '', scheduled_at: '' });
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to create booking');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      <div className="page-header">
        <h2>Bookings</h2>
        {user?.user_type === 'customer' && (
          <button className="btn btn-primary" onClick={() => setShowForm(!showForm)}>
            {showForm ? '✕ Cancel' : '+ New Booking'}
          </button>
        )}
      </div>

      <div className="page-body">
        {showForm && (
          <div className="card" style={{ padding: '1.75rem', marginBottom: '1.5rem' }}>
            <h3 style={{ marginBottom: '1.25rem' }}>Create Booking</h3>
            <form onSubmit={handleCreate} style={{ display: 'grid', gap: '1rem', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))' }}>
              <div className="form-group">
                <label className="form-label">Provider ID</label>
                <input className="form-input" placeholder="MongoDB ObjectId" required value={form.provider_id} onChange={(e) => setForm({ ...form, provider_id: e.target.value })} />
              </div>
              <div className="form-group">
                <label className="form-label">Service Name</label>
                <input className="form-input" placeholder="e.g. Plumbing Repair" required value={form.service_name} onChange={(e) => setForm({ ...form, service_name: e.target.value })} />
              </div>
              <div className="form-group">
                <label className="form-label">Amount (₹)</label>
                <input type="number" className="form-input" placeholder="500" required value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
              </div>
              <div className="form-group">
                <label className="form-label">Scheduled At</label>
                <input type="datetime-local" className="form-input" value={form.scheduled_at} onChange={(e) => setForm({ ...form, scheduled_at: e.target.value })} />
              </div>
              <div className="form-group" style={{ gridColumn: '1 / -1' }}>
                <label className="form-label">Description</label>
                <input className="form-input" placeholder="Brief description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
              </div>
              <div style={{ gridColumn: '1 / -1' }}>
                <button type="submit" className="btn btn-primary" disabled={submitting}>{submitting ? 'Creating…' : 'Create Booking'}</button>
              </div>
            </form>
          </div>
        )}

        <div className="table-wrapper">
          <table className="table">
            <thead>
              <tr>
                <th>Service</th>
                <th>{user?.user_type === 'customer' ? 'Provider' : 'Customer'}</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Payment</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={6} style={{ textAlign: 'center', padding: '2rem', color: 'var(--muted)' }}>Loading…</td></tr>
              ) : bookings.length === 0 ? (
                <tr><td colSpan={6} style={{ textAlign: 'center', padding: '2rem', color: 'var(--muted)' }}>No bookings found</td></tr>
              ) : bookings.map((b) => {
                const other = user?._id === b.customer_id?._id ? b.provider_id : b.customer_id;
                return (
                  <tr key={b._id}>
                    <td style={{ fontWeight: 500 }}>{b.service_name}</td>
                    <td>{other?.name || '—'}</td>
                    <td>₹{b.amount?.toLocaleString()}</td>
                    <td>{statusBadge(b.status)}</td>
                    <td><span className={`badge ${b.payment_status === 'paid' ? 'badge-green' : 'badge-yellow'}`}>{b.payment_status}</span></td>
                    <td style={{ display: 'flex', gap: 6 }}>
                      <Link to={`/chat/${b._id}`} className="btn btn-ghost" style={{ fontSize: '0.8rem', padding: '4px 10px' }}>Chat</Link>
                      {b.payment_status === 'unpaid' && user?.user_type === 'customer' && (
                        <Link to={`/payment/${b._id}`} className="btn btn-primary" style={{ fontSize: '0.8rem', padding: '4px 10px' }}>Pay</Link>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
