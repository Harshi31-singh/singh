import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../api/axios';

export default function Payment() {
  const { bookingId } = useParams();
  const navigate = useNavigate();
  const [booking, setBooking] = useState(null);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState(null); // 'success' | 'error'
  const [message, setMessage] = useState('');

  useEffect(() => {
    api.get(`/api/v1/bookings/${bookingId}`).then((res) => setBooking(res.data.data)).catch(console.error);
  }, [bookingId]);

  const loadRazorpay = () =>
    new Promise((resolve) => {
      if (window.Razorpay) return resolve(true);
      const script = document.createElement('script');
      script.src = 'https://checkout.razorpay.com/v1/checkout.js';
      script.onload = () => resolve(true);
      script.onerror = () => resolve(false);
      document.body.appendChild(script);
    });

  const handlePay = async () => {
    try {
      setLoading(true);

      const orderRes = await api.post('/api/v1/payments/create-order', {
        bookingId,
        amount: booking.amount,
      });

      const { orderId, amount, currency, key } = orderRes.data.data;

      const loaded = await loadRazorpay();
      if (!loaded) throw new Error('Failed to load Razorpay');

      const user = JSON.parse(localStorage.getItem('user') || '{}');

      const options = {
        key,
        amount,
        currency,
        name: 'AYARSHI',
        description: booking.service_name,
        order_id: orderId,
        handler: async (response) => {
          try {
            await api.post('/api/v1/payments/verify', {
              razorpayOrderId: response.razorpay_order_id,
              razorpayPaymentId: response.razorpay_payment_id,
              razorpaySignature: response.razorpay_signature,
            });
            setStatus('success');
            setMessage('Payment successful! Your booking is confirmed.');
            setTimeout(() => navigate('/dashboard'), 2500);
          } catch {
            setStatus('error');
            setMessage('Payment verification failed. Contact support.');
          }
        },
        prefill: { name: user.name, email: user.email, contact: user.phone },
        theme: { color: '#FF6B35' },
        modal: { ondismiss: () => setLoading(false) },
      };

      new window.Razorpay(options).open();
    } catch (err) {
      setStatus('error');
      setMessage(err.message || 'Payment failed');
      setLoading(false);
    }
  };

  if (!booking) return <div className="page-loading"><div className="spinner" /></div>;

  return (
    <>
      <div className="page-header">
        <h2>Complete Payment</h2>
      </div>

      <div className="page-body">
        <div className="payment-box">
          <div className="card" style={{ padding: '2rem' }}>
            {status === 'success' && (
              <div style={{ textAlign: 'center', padding: '1.5rem 0', color: 'var(--success)' }}>
                <div style={{ fontSize: '3rem' }}>✅</div>
                <p style={{ marginTop: '0.75rem', fontWeight: 600 }}>{message}</p>
              </div>
            )}

            {status === 'error' && (
              <div className="error-msg" style={{ marginBottom: '1rem' }}>{message}</div>
            )}

            {status !== 'success' && (
              <>
                <h3 style={{ marginBottom: '1.5rem' }}>Order Summary</h3>

                <div className="payment-summary">
                  <div className="payment-row">
                    <span>Service</span>
                    <span>{booking.service_name}</span>
                  </div>
                  <div className="payment-row">
                    <span>Status</span>
                    <span>{booking.status}</span>
                  </div>
                  <div className="payment-row">
                    <span>Total Amount</span>
                    <span className="payment-amount">₹{booking.amount?.toLocaleString()}</span>
                  </div>
                </div>

                <button
                  className="btn btn-primary"
                  style={{ width: '100%', padding: '1rem', fontSize: '1rem' }}
                  onClick={handlePay}
                  disabled={loading}
                >
                  {loading ? 'Processing…' : `Pay ₹${booking.amount?.toLocaleString()}`}
                </button>

                <p style={{ textAlign: 'center', fontSize: '0.78rem', color: 'var(--muted)', marginTop: '0.75rem' }}>
                  🔒 Secured by Razorpay
                </p>
              </>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
