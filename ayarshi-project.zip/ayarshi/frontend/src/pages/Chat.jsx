import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import ChatWindow from '../components/ChatWindow';
import { useAuth } from '../hooks/useAuth';
import api from '../api/axios';

export default function ChatPage() {
  const { bookingId } = useParams();
  const { user } = useAuth();
  const [conversations, setConversations] = useState([]);
  const [booking, setBooking] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/api/v1/chat/conversations').then((res) => {
      setConversations(res.data.data || []);
    }).catch(console.error).finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (bookingId) {
      api.get(`/api/v1/bookings/${bookingId}`).then((res) => {
        setBooking(res.data.data);
      }).catch(console.error);
    }
  }, [bookingId]);

  const otherUser = booking
    ? (booking.customer_id?._id === user?._id ? booking.provider_id : booking.customer_id)
    : null;

  return (
    <div style={{ display: 'flex', height: '100vh' }}>
      {/* Conversation list */}
      <div style={{ width: 300, borderRight: '1px solid var(--border)', background: 'white', display: 'flex', flexDirection: 'column' }}>
        <div style={{ padding: '1.25rem 1.5rem', borderBottom: '1px solid var(--border)' }}>
          <h3 style={{ fontFamily: 'Syne', fontSize: '1rem' }}>Messages</h3>
        </div>
        <div style={{ flex: 1, overflowY: 'auto' }}>
          {loading ? (
            <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--muted)' }}>Loading...</div>
          ) : conversations.length === 0 ? (
            <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--muted)', fontSize: '0.875rem' }}>
              No conversations yet
            </div>
          ) : conversations.map((c) => (
            <Link
              key={c.bookingId}
              to={`/chat/${c.bookingId}`}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.75rem',
                padding: '0.875rem 1.25rem',
                borderBottom: '1px solid var(--border)',
                background: c.bookingId === bookingId ? 'var(--brand-light)' : 'transparent',
                transition: 'background 0.15s',
              }}
            >
              <div className="chat-avatar" style={{ width: 36, height: 36, fontSize: '0.8rem' }}>
                {c.otherUser?.name?.[0]?.toUpperCase()}
              </div>
              <div style={{ flex: 1, overflow: 'hidden' }}>
                <div style={{ fontWeight: 600, fontSize: '0.875rem', display: 'flex', justifyContent: 'space-between' }}>
                  <span>{c.otherUser?.name}</span>
                  {c.unreadCount > 0 && (
                    <span style={{ background: 'var(--brand)', color: 'white', borderRadius: '999px', fontSize: '0.7rem', padding: '1px 7px' }}>
                      {c.unreadCount}
                    </span>
                  )}
                </div>
                <div style={{ fontSize: '0.78rem', color: 'var(--muted)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {c.lastMessage || c.serviceName}
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Chat window */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        {bookingId ? (
          <ChatWindow bookingId={bookingId} otherUser={otherUser} />
        ) : (
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', color: 'var(--muted)' }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>💬</div>
              <p>Select a conversation to start chatting</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
