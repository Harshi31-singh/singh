import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import api from '../api/axios';

const statusBadge = (status) => {
  const map = {
    pending: 'badge-yellow',
    confirmed: 'badge-blue',
    in_progress: 'badge-orange',
    completed: 'badge-green',
    cancelled: 'badge-gray',
  };
  return <span className={`badge ${map[status] || 'badge-gray'}`}>{status.replace('_', ' ')}</span>;
};

export default function Dashboard() {
  const { user } = useAuth();
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/api/v1/bookings').then((res) => {
      setBookings(res.data.data || []);
    }).catch(console.error).finally(() => setLoading(false));
  }, []);

  const stats = {
    total: bookings.length,
    active: bookings.filter((b) => ['pending', 'confirmed', 'in_progress'].includes(b.status)).length,
    completed: bookings.filter((b) => b.status === 'completed').length,
    revenue: bookings.filter((b) => b.payment_status === 'paid').reduce((s, b) => s + b.amount, 0),
  };

  return (
    <>
      <div className="page-header">
        <div>
          <h2>Welcome back, {user?.name?.split(' ')[0]} 👋</h2>
          <p style={{ color: 'var(--muted)', fontSize: '0.9rem', marginTop: 4 }}>Here's what's happening today</p>
        </div>
        <Link to="/bookings/new" className="btn btn-primary">+ New Booking</Link>
      </div>

      <div className="page-body">
        <div className="stats-grid">
          <div className="stat-card">
            <div className="stat-card-label">Total Bookings</div>
            <div className="stat-card-value">{stats.total}</div>
          </div>
          <div className="stat-card">
            <div className="stat-card-label">Active</div>
            <div className="stat-card-value stat-card-accent">{stats.active}</div>
          </div>
          <div className="stat-card">
            <div className="stat-card-label">Completed</div>
            <div className="stat-card-value">{stats.completed}</div>
          </div>
          <div className="stat-card">
            <div className="stat-card-label">Revenue Collected</div>
            <div className="stat-card-value stat-card-accent">₹{stats.revenue.toLocaleString()}</div>
          </div>
        </div>

        <div className="table-wrapper">
          <table className="table">
            <thead>
              <tr>
                <th>Service</th>
                <th>
                  {user?.user_type === 'customer' ? 'Provider' : 'Customer'}
                </th>
                <th>Amount</th>
                <th>Status</th>
                <th>Payment</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={6} style={{ textAlign: 'center', padding: '2rem', color: 'var(--muted)' }}>Loading...</td></tr>
              ) : bookings.length === 0 ? (
                <tr><td colSpan={6} style={{ textAlign: 'center', padding: '2rem', color: 'var(--muted)' }}>No bookings yet</td></tr>
              ) : bookings.map((b) => {
                const other = user?._id === b.customer_id?._id ? b.provider_id : b.customer_id;
                return (
                  <tr key={b._id}>
                    <td style={{ fontWeight: 500 }}>{b.service_name}</td>
                    <td>{other?.name || '—'}</td>
                    <td>₹{b.amount?.toLocaleString()}</td>
                    <td>{statusBadge(b.status)}</td>
                    <td>
                      <span className={`badge ${b.payment_status === 'paid' ? 'badge-green' : 'badge-yellow'}`}>
                        {b.payment_status}
                      </span>
                    </td>
                    <td>
                      <Link to={`/chat/${b._id}`} className="btn btn-ghost" style={{ fontSize: '0.8rem', padding: '4px 10px' }}>
                        Chat
                      </Link>
                      {b.payment_status === 'unpaid' && (
                        <Link to={`/payment/${b._id}`} className="btn btn-primary" style={{ fontSize: '0.8rem', padding: '4px 10px', marginLeft: '6px' }}>
                          Pay
                        </Link>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
