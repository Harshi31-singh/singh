import { useState, useEffect, useRef } from 'react';
import useChat from '../hooks/useChat';
import { useAuth } from '../hooks/useAuth';

export default function ChatWindow({ bookingId, otherUser }) {
  const [input, setInput] = useState('');
  const { user } = useAuth();
  const { messages, isTyping, isConnected, sendMessage, handleTyping, markAsRead } = useChat(bookingId);
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  useEffect(() => {
    messages.forEach((msg) => {
      const receiverId = msg.receiver_id?._id || msg.receiver_id;
      if (!msg.is_read && receiverId?.toString() === user?._id?.toString()) {
        markAsRead(msg._id || msg.id);
      }
    });
  }, [messages, markAsRead, user]);

  const handleSend = () => {
    if (!input.trim()) return;
    sendMessage(input);
    setInput('');
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const initials = otherUser?.name?.[0]?.toUpperCase() || '?';

  return (
    <div className="chat-container" style={{ height: '100%' }}>
      {/* Header */}
      <div className="chat-header">
        <div className="chat-header-left">
          <div className="chat-avatar">{initials}</div>
          <div>
            <div className="chat-user-name">{otherUser?.name || 'User'}</div>
            <div className="chat-status">{isConnected ? '● Online' : '○ Connecting...'}</div>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="messages-area">
        {messages.length === 0 && (
          <div className="empty-chat">
            <div className="empty-chat-icon">💬</div>
            <p>No messages yet. Say hello!</p>
          </div>
        )}

        {messages.map((msg) => {
          const senderId = msg.sender_id?._id || msg.sender_id;
          const isMine = senderId?.toString() === user?._id?.toString();
          const time = new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

          return (
            <div key={msg._id || msg.id} className={`message-bubble ${isMine ? 'sent' : 'received'}`}>
              <div className="message-content">{msg.message_text}</div>
              <div className="message-meta">
                {time}
                {isMine && <span style={{ marginLeft: 4 }}>{msg.is_read ? ' ✓✓' : ' ✓'}</span>}
              </div>
            </div>
          );
        })}

        {isTyping && (
          <div className="message-bubble received typing-bubble">
            <div className="message-content">
              <span className="typing-dot" />
              <span className="typing-dot" />
              <span className="typing-dot" />
            </div>
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="chat-input-area">
        <input
          className="chat-input"
          placeholder={isConnected ? 'Type a message…' : 'Connecting…'}
          value={input}
          onChange={(e) => { setInput(e.target.value); handleTyping(); }}
          onKeyDown={handleKeyDown}
          disabled={!isConnected}
        />
        <button className="btn-send" onClick={handleSend} disabled={!isConnected || !input.trim()}>
          ➤
        </button>
      </div>
    </div>
  );
}
